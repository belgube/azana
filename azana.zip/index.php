<?

$ch = curl_init('http://127.0.0.1:49195/');
curl_exec($ch); curl_close($ch);
?>
